# 터틀 그래픽 더 살펴보기-t.width( )

import turtle
t = turtle.Turtle()
t.shape("turtle")
t.width(10)

t.forward(100)
t.left(90)
t.forward(100)

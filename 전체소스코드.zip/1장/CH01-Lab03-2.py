#터틀 그래픽 더 살펴보기-color() 
import turtle

t = turtle.Turtle()
t.shape("turtle")
t.color("blue")

t.forward(100)
t.left(90)
t.forward(100)

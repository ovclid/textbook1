#터틀 그래픽 더 살펴보기-shape()

import turtle
t = turtle.Turtle()
t.shape("square")

t.forward(100)
t.left(90)
t.forward(100)

#CH06-006. 조건 제어 반복을 좀 더 이해시켜 줄 예제

password = ""
while password != "pythonisfun":
    password = input("암호를 입력하시오: ")
print("로그인 성공")

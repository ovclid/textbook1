#CH07-Lab01 주기율표를 외워보자

periodic_table = [ ]

periodic = input("주기율표 구절을 입력하시오: ")
periodic_table.append(periodic)
periodic = input("주기율표 구절을 입력하시오: ")
periodic_table.append(periodic)
periodic = input("주기율표 구절을 입력하시오: ")
periodic_table.append(periodic)
periodic = input("주기율표 구절을 입력하시오: ")
periodic_table.append(periodic)

print(periodic_table)

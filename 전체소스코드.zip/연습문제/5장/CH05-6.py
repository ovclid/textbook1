n = int(input("정수를 입력하시오: "))

if n%2==0 and n%3==0:
    print("2와 3으로 나누어떨어집니다.")
else :
    print("2와 3으로 나누어떨어지지 않습니다.")

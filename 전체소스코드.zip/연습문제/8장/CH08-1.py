def happyBirthday(person):
    print("Happy Birthday to you!")
    print("Happy Birthday to you!")
    print("Happy Birthday, dear " + person)
    print("Happy Birthday to you!")

name = input("이름을 입력하시오: ")
happyBirthday(name)
